#include "mbed.h"
#include "emic2.h"
 //serial RX,TX pins to emic
Serial xbee1(p9,p10);
DigitalOut rst1(p11);
//emic2 myTTS(p13, p14);
AnalogIn a1(p15);
AnalogIn a2(p16);
AnalogIn a3(p17);
AnalogIn a4(p18);
AnalogIn a5(p19);
Serial pc(USBTX, USBRX);
float i1;
float i2;
float i3;
float i4;
float i5;
float ref1;
float ref2;
float ref3;
float ref4;
float ref5;



int counter;

int main() {
    counter = 0;
    rst1 = 0;
    wait_ms(1); 
    rst1 = 1;
    wait_ms(1);
    float avg = 0;
    float max = 0;
    float diff = 0;
    char c;
    while(1) {
        if (counter % 100) //update reference data every 100 inputs
        {
            ref1 = a1;
            ref2 = a2;
            ref3 = a3;
            ref4 = a4;
            ref5 = a5;
            
        }
        counter++;
        wait(0.5);
        i1 = a1;
        i2 = a2;
        i3 = a3;
        i4 = a4;
        i5 = a5;
        
        c = 'I';
        if (i1 > i2) {
            max = i1;
            c = 'A';
        } else
        {
            max = i2;
            c = 'B';
        }
        if (max < i3)
        {
            max = i3;
            c = 'C';
        }
        if (max < i4)
        {
            max = i4;
            c = 'D';
        }
        if (max < i5)
        {
            max = i5;
            c = 'E';
        }
        avg = (i1 + i2 + i3 + i4 + i5) / 5;
        diff = max - avg;
        if (diff*100 > 0.77 & diff*100 < 5)
        {
            xbee1.putc(c);
        } else
        {  
            xbee1.putc ('I');
        }
        pc.printf("%4.2f ", diff*100);
    }
}
